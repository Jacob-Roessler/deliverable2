# DuckBooks

A way to check out books remotely from the Stevens Library.
